
Other datatypes
===============
Defines methods for some other datatypes
