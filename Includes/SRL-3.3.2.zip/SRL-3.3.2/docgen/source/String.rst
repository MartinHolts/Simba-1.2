
String
======
String related methods
 
 `AnsiString` is used instead of `string`, because 
  code completion doesn't support `string`
  
  Another code completion workaround:

  Copy the string from after the first occurrence of SubStr

  Copy the string from before the first occurrence of SubStr

  Count the number of occurrences of the given string.

  Replace occurrences of the given SubStr with with ReplaceStr
  For larger string this algorithm is way faster than `Replace` in Simba.

  Fix me!!!

  Blow up the string at each delimiter into smaller strings

  test if a string only contains alpha numerical characters.

  test if a sting is a digit

  test if a string is a floating point number

  test if a string only contains letters a-zA-Z

  Extract all the numbers found in the string.

  Extract all the numbers found in the string.

  File extension and name
