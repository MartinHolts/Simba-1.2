
GrandExchange
==============

This file is a work in progress.
In other words:
* it will be a subject to change
* it doesn't have any documentation
* it may lack a lot of safety checks
* it will no be included by default
* it could contain bugs

- slacky was here!
