
T2DExtendedArray
================
T2DExtendedArray related methods
