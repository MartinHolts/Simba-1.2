
TBox
=========
TBox related methods

TBox.NearestEdge
~~~~~~~~~~~~~~~~
.. code-block:: pascal

    function TBox.NearestEdge(P: TPoint): TPoint; constref;

Returns the closest edge point to the TPoint `P`.

.. note:: by slacky
