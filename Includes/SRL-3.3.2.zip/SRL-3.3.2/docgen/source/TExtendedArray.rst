
TExtendedArray
==============
TExtendedArray related methods
