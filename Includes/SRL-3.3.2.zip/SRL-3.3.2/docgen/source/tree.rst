
    SlackTree is a static tree for quick "spatial lookups".
    Allows quick nearest neighbour lookup, and range-query. 
    
    Note: Might still exists some bugs here.
  
 Allows you to select the nth element in a TPA 
