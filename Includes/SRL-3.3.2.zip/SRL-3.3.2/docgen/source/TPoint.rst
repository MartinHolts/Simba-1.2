
TPoint
=============
TPoint related methods
