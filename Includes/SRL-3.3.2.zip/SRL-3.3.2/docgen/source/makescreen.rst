
MakeScreen
==============
This file stores all methods that are used for simpler interfaces like SmithingScreen.

.. code-block:: pascal

    Writeln(SmithingScreen.IsOpen());
