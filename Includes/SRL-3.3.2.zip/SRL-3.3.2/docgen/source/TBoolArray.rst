
TBoolArray
==========
TBoolArray related methods
