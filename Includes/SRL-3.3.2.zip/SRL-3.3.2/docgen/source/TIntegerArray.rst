
TIntegerArray
=============
TIntegerArray related methods
