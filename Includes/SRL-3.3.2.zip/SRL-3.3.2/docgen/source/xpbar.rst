
XPBar
======
XPBar related methods

XPBar.Read
~~~~~~~~~~
.. code-block:: pascal

  function TXPBar.Read: Integer;

Opens the XPBar if needed and returns the current total.
