
 Returns all the points from `self` that are within range of any point in `other`.
 The parameters `mindist` and `maxdist` determine what "within range" means.

 same as the above but lets you specify X- and Y-wise distance separately. This allows
 for a lot of cool stuff :p

 An older version with some other parameters from what the above takes.
 I'll just drop it here.
