
MM2MS
=======
The core for our minimap to mainscreen projection.
Supports rotation, and zoom, and resizable client.
